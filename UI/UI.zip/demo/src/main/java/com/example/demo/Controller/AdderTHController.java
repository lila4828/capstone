package com.example.demo.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdderTHController {
    @RequestMapping("/")
    public String formPage() {
        return "view/main-1/index";
    }

    @PostMapping("/table")
    public String formSubmittable(@RequestParam("search") String search, Model model) {
        model.addAttribute("search", search);
        return "view/table/index";
    }
    @PostMapping("/list")
    public String formSubmitlist(@RequestParam("search") String search, Model model) {
        model.addAttribute("search", search);
        return "view/list/index";
    }
}
